# Install dependencies before running:
# pip install rdflib networkx torch torch-geometric pandas neo4j

import os
import rdflib
import networkx as nx
import torch
from torch_geometric.data import Data
from torch_geometric.nn import GCNConv, TopKPooling
import pandas as pd
from neo4j import GraphDatabase

# ------------------------------ Neo4j Credentials -------------------------------
# Fill in your Neo4j credentials here.
NEO4J_URI = "neo4j+s://ae161786.databases.neo4j.io"    # e.g., "neo4j+s://abcd1234.databases.neo4j.io"
NEO4J_USER = "neo4j"                   # e.g., "neo4j"
NEO4J_PASSWORD = "tAJ21QS59JSJorrM9st2uxiTPPvp6g3fRobFeE77VOQ"               # e.g., "my-secret-password"
# ------------------------------------------------------------------------------
# Create a Neo4j driver instance using the credentials.
driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))


# Helper function to extract a human-readable name from a node identifier.
def extract_name(node):
    node_str = str(node)
    # Try splitting by '/' or '#' and take the last segment.
    if "/" in node_str:
        return node_str.split("/")[-1]
    elif "#" in node_str:
        return node_str.split("#")[-1]
    else:
        return node_str

# Step 1: Load the knowledge graph from the TTL file into a NetworkX graph.
def load_rdf_graph(ttl_file):
    g = rdflib.Graph()
    g.parse(ttl_file, format="ttl")
    nx_graph = nx.DiGraph()
    for s, p, o in g:
        nx_graph.add_edge(str(s), str(o), label=str(p))
    return nx_graph

# Step 2: Convert the NetworkX graph to a PyTorch Geometric Data object.
def convert_to_pyg_data(nx_graph):
    nodes = list(nx_graph.nodes())
    node_mapping = {node: i for i, node in enumerate(nodes)}
    names_mapping = {node: extract_name(node) for node in nodes}
    
    edge_index_list = []
    for u, v in nx_graph.edges():
        edge_index_list.append([node_mapping[u], node_mapping[v]])
    edge_index = torch.tensor(edge_index_list, dtype=torch.long).t().contiguous()
    
    # Random features; replace with your own features if available.
    x = torch.randn((len(nodes), 16))
    
    data = Data(x=x, edge_index=edge_index)
    # Dummy batch assignment required for pooling.
    data.batch = torch.zeros(data.x.size(0), dtype=torch.long)
    return data, nodes, node_mapping, names_mapping

# Step 3: Define a GCN model with TopKPooling for node reduction.
class GCNWithPooling(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, pooling_ratio=0.5):
        super(GCNWithPooling, self).__init__()
        self.conv1 = GCNConv(in_channels, hidden_channels)
        self.pool = TopKPooling(hidden_channels, ratio=pooling_ratio)
        self.conv2 = GCNConv(hidden_channels, in_channels)
    
    def forward(self, data):
        x, edge_index, batch = data.x, data.edge_index, data.batch
        x = torch.relu(self.conv1(x, edge_index))
        # Pooling: reduces number of nodes.
        x, edge_index, _, batch, perm, score = self.pool(x, edge_index, batch=batch)
        x = self.conv2(x, edge_index)
        return x, perm, edge_index

# Step 4: Apply the GCN with pooling to reduce node count.
def apply_gcn_with_pooling(data, pooling_ratio=0.5):
    model = GCNWithPooling(data.x.size(1), hidden_channels=16, pooling_ratio=pooling_ratio)
    model.eval()  # In evaluation mode; adjust as needed.
    with torch.no_grad():
        pooled_embeddings, perm, new_edge_index = model(data)
    return pooled_embeddings, perm, new_edge_index

# Step 5: Export the reduced graph to CSV files.
def export_to_neo4j_reduced(nodes, names_mapping, pooled_embeddings, perm, new_edge_index):
    # Map pooled indices back to original node IDs.
    reduced_nodes = [nodes[i] for i in perm.tolist()]
    
    df_nodes = pd.DataFrame({
        "id": reduced_nodes,
        "name": [names_mapping[node] for node in reduced_nodes],
        "embedding": [pooled_embeddings[i].tolist() for i in range(pooled_embeddings.size(0))]
    })
    df_nodes.to_csv("nodes_reduced.csv", index=False)
    
    # Process reduced edges.
    edges = new_edge_index.t().tolist()
    df_edges = pd.DataFrame({
        "source": [reduced_nodes[u] for u, v in edges],
        "target": [reduced_nodes[v] for u, v in edges]
    })
    df_edges.to_csv("edges_reduced.csv", index=False)

# Optional: Example function to import nodes and edges directly into Neo4j using the driver.
def import_into_neo4j(nodes_csv, edges_csv):
    with driver.session() as session:
        # Import nodes.
        df_nodes = pd.read_csv(nodes_csv)
        for idx, row in df_nodes.iterrows():
            query = """
            MERGE (n:Entity {id: $id})
            SET n.name = $name, n.embedding = $embedding
            """
            session.run(query, id=row["id"], name=row["name"], embedding=row["embedding"])
        
        # Import edges.
        df_edges = pd.read_csv(edges_csv)
        for idx, row in df_edges.iterrows():
            query = """
            MATCH (a:Entity {id: $source}), (b:Entity {id: $target})
            MERGE (a)-[:RELATES_TO]->(b)
            """
            session.run(query, source=row["source"], target=row["target"])

# Main Execution
if __name__ == "__main__":
    ttl_file = "test_dataset.ttl"
    nx_graph = load_rdf_graph(ttl_file)
    data, nodes, node_mapping, names_mapping = convert_to_pyg_data(nx_graph)
    
    # Apply GCN with pooling to reduce nodes (adjust pooling_ratio as desired).
    pooled_embeddings, perm, new_edge_index = apply_gcn_with_pooling(data, pooling_ratio=0.5)
    
    # Export reduced graph data to CSV files.
    export_to_neo4j_reduced(nodes, names_mapping, pooled_embeddings, perm, new_edge_index)
    print("GCN with pooling applied. Reduced graph data exported as 'nodes_reduced.csv' and 'edges_reduced.csv'.")

    # Optional: Import directly into Neo4j using the provided credentials.
    # Uncomment the next line to run the import (ensure CSV files are available and paths are correct).
    import_into_neo4j("nodes_reduced.csv", "edges_reduced.csv")
    
    # Clean up the Neo4j driver when done.
    driver.close()
