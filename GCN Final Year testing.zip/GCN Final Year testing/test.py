import rdflib
import random

# Load the full RDF graph
g = rdflib.Graph()
g.parse("agriculture_kg_fully_fixed.ttl", format="ttl")

# Convert all triples to a list
triples = list(g)

# Shuffle and split to get 20%
random.shuffle(triples)
test_size = int(len(triples) * 0.2)
test_triples = triples[:test_size]

# Create a new graph for the test data
test_graph = rdflib.Graph()
for triple in test_triples:
    test_graph.add(triple)

# Save to a new .ttl file
test_graph.serialize(destination="test_dataset.ttl", format="ttl")
print(f"Test dataset saved with {len(test_triples)} triples.")
